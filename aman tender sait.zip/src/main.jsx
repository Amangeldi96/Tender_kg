import React from "react";
import { createRoot } from "react-dom/client";
import App from "./app.jsx";

const root = document.getElementById("root");
if (!root) throw new Error("index.html ичинде #root табылган жок");
createRoot(root).render(<React.StrictMode><App /></React.StrictMode>);
